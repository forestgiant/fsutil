(function () {'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var videojs = _interopDefault(require('video.js'));

var Stela = require('stela-api').default;
var SourceHub = require('source-hub-api').default;
var hub;
var stela;
var hubws;
var time = 0;
var videoInstance;

document.addEventListener('DOMContentLoaded', function() {
    // Create the stela instance
    stela = new Stela('http://localhost:9000');

    // Discover and create a source hub instance
    stela.discoverOne('source-hub.service.fg').then(function(body) {
      // Create the source hub instance
      hub = new SourceHub(body.address + ":" + body.port);

      hub.create('video-time').then(function(body){
        console.log(body);
      });

      // Open upa socket connection with source hub
      hubws = hub.connect('video-time');

      // Listen to any messages received from the source hub socket
      hubws.ws.on('message', function message(data, flags){
        var result = JSON.parse(bin2String(data));
        time = atob(result.KeyValuePair.Value);
        videoInstance.currentTime(time);
      });

      var vws = hub.connect('proximity');

      vws.ws.on('message', function message(data, flags){
        var result = JSON.parse(bin2String(data));
        var percent = atob(result.KeyValuePair.Value);
        console.log(percent);
        if (percent > .80) {
          videoInstance.play();
          document.getElementById("sampleVideo").style.webkitFilter = "blur(0px)";
        } else {
          videoInstance.pause();
          var blur = calculateBlur(percent)
          console.log(blur);
          document.getElementById("sampleVideo").style.webkitFilter = "blur("+blur.toString()+"px)";
        }
      });
    });

    // Create our video instance
    videojs('sampleVideo', { /* Options */ }, function() {
        videoInstance = this;

        this.currentTime(time);

        this.on('ended', function() {
            console.log('awww...over so soon?');
        });

        sendPausedTime(this);
    });
});

var currentTime = 0;

function sendPausedTime(self) {
  setInterval(function() {
    if (self.paused()) {
      if (currentTime != self.currentTime()) {
        currentTime = self.currentTime();
        console.log('sending paused time to source hub', currentTime);
        hubws.send('time', currentTime);
      }
    }
  }, 100)
}

function bin2String(array) {
  return String.fromCharCode.apply(String, array);
}

function calculateBlur(percent) {
  var v = 1 - parseFloat(percent) + 0;
  return v * 10
}
}());
//# sourceMappingURL=app.js.map